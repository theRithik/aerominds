
const endpoints = {
// url:"http://localhost:5000",
 url:"https://qxlhvvuj7b.execute-api.ap-south-1.amazonaws.com/prod",

// user
query:'/user/query',


}

export default endpoints