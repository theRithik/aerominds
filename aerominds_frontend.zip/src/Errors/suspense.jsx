import React from "react";

const RoutingSuspense =()=>{
    return(
        <>
         <div style={{display:'flex',justifyContent:'center',height:'100vh',alignItems:'center',textAlign:'center'}}>
            <img src="/images/logoloading.webp" style={{width:300}} className="logoloading" alt="loading"/>
        </div>
        </>
    )
}
export default RoutingSuspense